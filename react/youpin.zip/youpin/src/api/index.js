// 三个模块 
import product, {zz} from './product';

const api = {
  product
}

export default api;