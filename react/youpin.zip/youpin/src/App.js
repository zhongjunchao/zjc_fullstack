import logo from './logo.svg';
import './App.css';
import Detail from './pages/Detail'
function App() {
  return (
    <>
      <Detail />
    </>
  );
}

export default App;
