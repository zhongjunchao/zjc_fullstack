[source](https://github.com/qiangliyu/-React-/blob/master/src/store/index.js)
- redux-logger 用法

## 电商网站

1. 商品
  - 列表 (首页) /home  reducer productReducer  list  changeList  api/  express
  - 详情 /detail/:id reducer productReducer  detail  changeDetail  api/ express
2. 购物车  /cart  reducer cartReducer 
3. 我的 /my reducer  userReducer 
小米有品， 抄小米有品页面


